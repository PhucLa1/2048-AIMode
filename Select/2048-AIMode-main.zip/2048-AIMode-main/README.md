Use AI to beat 2048
